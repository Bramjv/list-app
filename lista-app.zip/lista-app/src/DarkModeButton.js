import React from 'react';

const DarkModeButton = ({ darkMode, toggleDarkMode }) => {
  return (
    <button className='button' onClick={toggleDarkMode}>
      {darkMode ? 'Tryb ciemny' : 'Tryb jasny'}
    </button>
  );
};

export default DarkModeButton;